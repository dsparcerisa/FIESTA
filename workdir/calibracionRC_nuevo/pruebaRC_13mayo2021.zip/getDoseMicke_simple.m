function [dose, varMat, realDR, realDG, realDB] = getDoseMicke_simple(I, CoefR, CoefG, CoefB, deltas, pxmax)

%% Definir funciones
DR = @(pv) CoefR(3) + CoefR(2)./(pv - CoefR(1));
DG = @(pv) CoefG(3) + CoefG(2)./(pv - CoefG(1));
DB = @(pv) CoefB(3) + CoefB(2)./(pv - CoefB(1));
aR = @(pv) -CoefR(2) ./ (pv - CoefR(1)).^2;
aG = @(pv) -CoefG(2) ./ (pv - CoefG(1)).^2;
aB = @(pv) -CoefB(2) ./ (pv - CoefB(1)).^2;

correctedDR = @(pv,delta) DR(pv) + aR(pv).*delta;
correctedDG = @(pv,delta) DG(pv) + aG(pv).*delta;
correctedDB = @(pv,delta) DB(pv) + aB(pv).*delta;

pvR = double(I(:,:,1)) / pxmax;
pvG = double(I(:,:,2)) / pxmax;
pvB = double(I(:,:,3)) / pxmax;

if ~exist('deltas')
    delta = -0.2:0.001:0.2;
else
    delta = deltas;
end

% Perturbed dose 
dev_min = 1.e30*ones(size(I,1),size(I,2));
delta0 = nan(size(I,1),size(I,2));

% Primero sin tener en cuenta los l�mites
for k = 1:numel(delta)
    dev = (correctedDR(pvR,delta(k))-correctedDG(pvG,delta(k))).^2 + ...
        (correctedDR(pvR,delta(k))-correctedDB(pvB,delta(k))).^2 + ...
        (correctedDB(pvB,delta(k))-correctedDG(pvG,delta(k))).^2;
    maskMin = dev<dev_min;
    dev_min(maskMin) = dev(maskMin);
    delta0(maskMin) = delta(k);
end

realDR = correctedDR(pvR,delta0);
realDG = correctedDG(pvG,delta0);
realDB = correctedDB(pvB,delta0);

% Y luego teni�ndolos en cuenta
isR = double(realDG<10 & realDR<10);
isB = double(realDG>2 & realDB>2);

for k = 1:numel(delta)
    dev = isR.*(correctedDR(pvR,delta(k))-correctedDG(pvG,delta(k))).^2 + ...
        isR.*isB.*(correctedDR(pvR,delta(k))-correctedDB(pvB,delta(k))).^2 + ...
        isB.*(correctedDB(pvB,delta(k))-correctedDG(pvG,delta(k))).^2;
    maskMin = dev<dev_min;
    dev_min(maskMin) = dev(maskMin);
    delta0(maskMin) = delta(k);
end

realDR = correctedDR(pvR,delta0);
realDG = correctedDG(pvG,delta0);
realDB = correctedDB(pvB,delta0);

doseRGB = (isR.*realDR+realDG+isB.*realDB)./ (1 + isR + isB);

%figure(1); imagesc(doseRGB); title('Dose map (RGB)'); caxis([0 10]);
%figure(2); imagesc(delta0); title('Delta0'); caxis([0.8 1.2]);

% Create simple outputs
dose = doseRGB;
varMat = delta0;

end


